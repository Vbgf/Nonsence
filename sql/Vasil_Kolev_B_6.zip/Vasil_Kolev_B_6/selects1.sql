SELECT DISTINCT article, tag
FROM TagUser, ArticleCategory
WHERE article = 1;