DROP DATABASE IF EXISTS exam;
CREATE DATABASE exam;
USE exam;

CREATE TABLE Article_5(
	id INT AUTO_INCREMENT NOT NULL,
	price INT,
	created_on TIMESTAMP,
	password VARCHAR(255),
	PRIMARY KEY(id)
);

CREATE TABLE Category(
	id INT AUTO_INCREMENT NOT NULL,
	description LONG VARCHAR,
	priority INT,
	PRIMARY KEY(id)
);

CREATE TABLE User(
	id INT AUTO_INCREMENT NOT NULL,
	gender VARCHAR(6),
	twitter VARCHAR(255),
	password VARCHAR(255),
	PRIMARY KEY(id)
);

CREATE TABLE Tag(
	id INT AUTO_INCREMENT NOT NULL,
	description VARCHAR(255),
	priority INT,
	PRIMARY KEY(id)
);


CREATE TABLE ArticleCategory(
	id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
	article INT NOT NULL,
	category INT NOT NULL,
	FOREIGN KEY (article) REFERENCES Article_5(id),
	FOREIGN KEY (category) REFERENCES Category(id)
);

CREATE TABLE CategoryTag(
	id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
	category INT NOT NULL,
	tag INT NOT NULL,
	FOREIGN KEY (category) REFERENCES Category(id),
	FOREIGN KEY (tag) REFERENCES Tag(id)
);

CREATE TABLE TagUser(
	id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
	tag INT NOT NULL,
	user INT NOT NULL,
	FOREIGN KEY (tag) REFERENCES Tag(id),
	FOREIGN KEY (user) REFERENCES User(id)
);