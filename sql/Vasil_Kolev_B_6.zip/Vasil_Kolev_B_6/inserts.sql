Use exam;

INSERT INTO Article_5 (price, password)
VALUES (10, "12354567"),
(1000, "0093030");

INSERT INTO Category (description, priority)
VALUES ("des1", 3),
("des2", 14);

INSERT INTO User (gender, twitter, password)
VALUES ("male", "@first", "asdf"),
("female", "@second", "ttxtt");

INSERT INTO Tag (description, priority)
VALUES ("des11", 33),
("de12", 34);

INSERT INTO ArticleCategory (article, category)
VALUES (1, 1),
(1, 2);

INSERT INTO CategoryTag (category, tag)
VALUES (2, 1),
(1, 2);

INSERT INTO TagUser (tag, user)
VALUES (2, 1),
(1, 1);

